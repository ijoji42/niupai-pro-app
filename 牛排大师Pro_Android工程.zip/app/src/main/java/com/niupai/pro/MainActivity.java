package com.niupai.pro;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;

public class MainActivity extends Activity {
    public void onCreate(Bundle b){
        super.onCreate(b);
        WebView w=new WebView(this);
        w.getSettings().setJavaScriptEnabled(true);
        w.loadUrl("https://niupaipro.pages.dev");
        setContentView(w);
    }
}
